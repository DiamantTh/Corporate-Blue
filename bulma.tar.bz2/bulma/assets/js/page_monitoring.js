// Internationalization:
// - https://www.chartjs.org/docs/latest/configuration/locale.html
// - By default the chart is using the default locale of the platform which is running on.
// - options: { locale: 'en' }
// - we override it in various places, as we use the Intl.NumberFormat

function getNumberFormat(decimals = 0)
{
    return new Intl.NumberFormat(hash['language'].replace('_', '-'), { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

var numberFormatInt = getNumberFormat(0);
var numberFormatFloat = getNumberFormat(2);
var numberFormatFloat3 = getNumberFormat(3);


var charts = $('.app-chart');

charts.each(function() {
    var datasets = $(this).data('chart-datasets');
    var yAxis = $(this).data('chart-y-axis');

    // Scale / Value formatting
    var yScaleTickCallback = Chart.defaults.scales.linear.ticks.callback;
    var tooltipLabelCallback = Chart.defaults.plugins.tooltip.callbacks.label;

    switch (yAxis)
    {
        case 'percent':
            yScaleTickCallback = function (value) {
                return value + '%';
            };
            tooltipLabelCallback = function(context) {
                let label = context.dataset.label ? context.dataset.label + ': ' : '';
                return label + context.raw.toFixed(2) + '%';
            };
            break;

        case 'integer':
            yScaleTickCallback = function (value) {
                return value % 1 === 0 ? numberFormatInt.format(value) : null;
            };
            tooltipLabelCallback = function(context) {
                let label = context.dataset.label ? context.dataset.label + ': ' : '';
                let value = numberFormatInt.format(Math.round(context.raw));
                return label + value;
            };
            break;

        case 'float':
            // No need for yScaleTickCallback for now.

            tooltipLabelCallback = function(context) {
                let label = context.dataset.label ? context.dataset.label + ': ' : '';
                let value = numberFormatFloat.format(context.raw.toFixed(2));
                return label + value;
            };
            break;

        case 'bytes':
            yScaleTickCallback = function (value) {
                return formatBytes(value, 1);
            };
            tooltipLabelCallback = function(context) {
                let label = context.dataset.label ? context.dataset.label + ': ' : '';
                return label + formatBytes(context.raw, 1);
            };
            break;

        case 'time':
            yScaleTickCallback = function (value) {
                return value + ' ms';
            };
            tooltipLabelCallback = function(context) {
                let label = context.dataset.label ? context.dataset.label + ': ' : '';
                let value = numberFormatFloat3.format(context.raw);
                return label + value + ' ms';
            };
    }

    // Colors / Apperiance
    var colors = [
        { light: '#36A2EB', dark: '#3273DC' },
        { light: '#FF6384', dark: '#FF2B56' },
        { light: '#FF9F40', dark: '#FFDD57' },
        { light: '#4BC0C0', dark: '#0CA661' },
        { light: '#FFCD56', dark: '#FF8457' },
        { light: '#9966FF', dark: '#9966FF' },
        { light: '#C9CBCF', dark: '#3D3D3D' },
        { light: '#000000', dark: '#000000' }  // currently not used, only idicator
    ];

    let colorCode, alpha;
    for (let i = 0; i < datasets.length; i++)
    {
        colorCode = hash['theme.is_dark_mode'] ? colors[i].dark : colors[i].light;
        alpha = hash['theme.is_dark_mode'] ? '90' : '80';

        datasets[i]['borderColor'] = colorCode;
        datasets[i]['backgroundColor'] = colorCode + alpha;
    }

    // Smooth curves between points
    Chart.overrides.line.tension = 0.3;
    Chart.defaults.elements.line.borderWidth = 2.5; // default = 3

    new Chart(this, {
        type: 'line',
        data: {
            labels: graphDataPoints,
            datasets: datasets
        },
        options: {
            animation: false,
            // Needs to be false, in order to make the chartjs use the canvas parent style sizes.
            maintainAspectRatio: false,
            interaction: {
                // When hovering over a data point, all other data points will be displayed in the tooltip too.
                mode: 'index'
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    align: 'start'
                },
                tooltip: {
                    callbacks: {
                        label: tooltipLabelCallback,
                        title: function(a) {
                            // https://www.youtube.com/watch?v=GnRAbf9MMQI
                            const d = new Date(a[0].parsed.x);
                            const formattedDate = d.toLocaleDateString([], {
                                year: 'numeric',
                                month: '2-digit',
                                day: '2-digit',
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: false
                            });
                            return formattedDate;
                        }
                    }
                },
//                colors: {
//      enabled: false
//    }
            },
            elements: {
                point: {
                    radius: 0,
                    hitRadius: 8
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: {
                        displayFormats: {
                            minute: 'HH:mm',        // < 12h
                            hour: 'HH:mm',          // < 30d
                            quarter: 'MMM YYYY'
                        }
                    },
                    ticks: {
                        autoSkip: true,
                        maxTicksLimit: 6
                        //stepSize: 5
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: yScaleTickCallback
                    }
                }
            }
        }
    });
});